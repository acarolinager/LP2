﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] timeFut = new int[6, 3];
            string aux = "";
            int saldo = 0;

            for(var linha = 0; linha < 6; linha++)
            {
                for(var col = 0; col < 3; col++)
                { 
                    if(col == 0)
                    {
                        aux = Interaction.InputBox("Numero de gols FEITOS " +
                        "Time= " + (linha + 1), "Entrada de dados");

                        lbltxtListagem.Items.Add(">> Time: " + (linha + 1) + " Gols FEITOS: " + col);
                        col++;
                    }
                    if(col == 1)
                    {
                        aux = Interaction.InputBox("Numero de gols RECEBIDOS " +
                        "Time= " + (linha + 1), "Entrada de dados");

                        lbltxtListagem.Items.Add(">> Gols RECEBIDOS: " + col);
                        col++;
                    }
                    if(col == 2)
                    {
                        saldo += timeFut[linha,col];
                        lbltxtListagem.Items.Add(">> Saldo: " + saldo);
                        lbltxtListagem.Items.Add("-------------------------------------------");
                    }

                }  
            }
        }
    }
}
